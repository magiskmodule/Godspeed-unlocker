SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true
CLEANSERVICE=true
DEBUG=true
MODDIR=/data/adb/modules
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2
unzip -o "$ZIPFILE" 'tmp/*' -d $MODPATH >&2
ui_print "    
    ┏━━━┳━━━┓┏┓╋┏┳━┓╋┏┳┓╋╋┏━━━┳━━━┳┓┏━┳━━━┳━━━┓
    ┃┏━┓┃┏━┓┃┃┃╋┃┃┃┗┓┃┃┃╋╋┃┏━┓┃┏━┓┃┃┃┏┫┏━━┫┏━┓┃
    ┃┃╋┗┫┗━━┓┃┃╋┃┃┏┓┗┛┃┃╋╋┃┃╋┃┃┃╋┗┫┗┛┛┃┗━━┫┗━┛┃
    ┃┃┏━╋━━┓┃┃┃╋┃┃┃┗┓┃┃┃╋┏┫┃╋┃┃┃╋┏┫┏┓┃┃┏━━┫┏┓┏┛
    ┃┗┻━┃┗━┛┃┃┗━┛┃┃╋┃┃┃┗━┛┃┗━┛┃┗━┛┃┃┃┗┫┗━━┫┃┃┗┓
    ┗━━━┻━━━┛┗━━━┻┛╋┗━┻━━━┻━━━┻━━━┻┛┗━┻━━━┻┛┗━┛"
sleep 01
sleep 1
ui_print "    •DEVICE INFORMATION: "
sleep 0.2
ui_print "    •DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "    •BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "    •MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "    •KERNEL : $(uname -r) "
sleep 0.2
ui_print "    •PROCESSOR : $(getprop ro.product.board) "

sleep 3
. $TMPDIR/addon/Volume-Key-Selector/install.sh

sleep 10
ui_print "    •GAME UNLOCKER "
sleep 0.2
ui_print "[!]     •1. CODM And BLACKDESERT MOBILE "
sleep 0.2
ui_print "[!]     •2. PUBGM And ASPHALT 9 (DEAD TRIGGER 2 /PUBGM /BGMI) "
sleep 0.2
ui_print "[!]     •3. Mobile Legends "
sleep 0.2
ui_print "[!]     •4. COD Mobile - 120 FPS "
sleep 0.2
ui_print "[!]     •5. League of Legends - 120FPS "
sleep 0.2
ui_print "[!]     •6. Arena Of Valor "
sleep 0.2
ui_print "[!]     •7. Fortnite "
am start -a android.intent.action.VIEW -d https://strideovertakelargest.com/u0xs36mu8?key=813a284c6297605783693cce073b8e99 >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
sleep 0.2
ui_print "[!]     •8. PUBG NEW STATE "
ui_print "[!]     •9. RULES OF SURVIVORS  "
ui_print "[!]     •10.PUBG MOBILE HDR EXTREME  "
ui_print "[!]     •11.PUBG MOBILE & BGMI 90 FPS  "

sleep 0.2
ui_print "[!]     •12. SKIP "
sleep 0.2
ui_print " Select what you desire : "
GSU=1
while true; do
ui_print "  $GSU"
if $VKSEL; then
GSU=$((GSU + 1))
else
break
fi
if [ $GSU -gt 12 ]; then
GSU=1
fi
done
ui_print " Selected: $GSU "
case $GSU in
1 ) TEXT3="✓CODM And BLACKDESERT MOBILE "; FCTEXT=" CODM And BlackDesert Mobile "; sed -i '/ro.product.model/s/.*/ro.product.model=SM-G965F/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=SM-G965F/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=SM-G965F/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=SM-G965F/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=SM-G965F/' $MODPATH/system.prop;;
2 ) TEXT3="✓PUBGM AND ASPHALT 9 "; FCTEXT=" PUBGM And ASPHALT 9 "; sed -i '/ro.product.model/s/.*/ro.product.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=GM1917/' $MODPATH/system.prop;;
3 ) TEXT3="✓MOBILE LEGENDS"; FCTEXT="Mobile Legends"; sed -i '/ro.product.model/s/.*/ro.product.model=Mi 10 Pro/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=Mi 10 Pro/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=Mi 10 Pro/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=Mi 10 Pro/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=Mi 10 Pro/' $MODPATH/system.prop;;
4 ) TEXT3="✓CODM "; FCTEXT="COD Mobile"; sed -i '/ro.product.model/s/.*/ro.product.model=SO-52A/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=SO-52A/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=SO-52A/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=SO-52A/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=SO-52A/' $MODPATH/system.prop;;
5 ) TEXT3="✓LEAGUE OF LEGANDS "; FCTEXT="League of Legends"; sed -i '/ro.product.model/s/.*/ro.product.model=SM-G9880/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=SM-G9880/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=SM-G9880/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=SM-G9880/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=SM-G9880/' $MODPATH/system.prop;;
6 ) TEXT3="✓AOV "; FCTEXT="Arena Of Valor"; sed -i '/ro.product.model/s/.*/ro.product.model=R11 Plus/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=R11 Plus/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=R11 Plus/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=R11 Plus/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=R11 Plus/' $MODPATH/system.prop;;
7 ) TEXT3="✓FORTNITE "; FCTEXT="Fortnite"; chmod 0777 $GAMEUSERSETTINGS_FILE; magiskhide enable; magiskhide add com.epicgames.fortnite; settings put global adb_enabled 0; mv /data/media/0/TWRP /data/media/0/PRWT; mv /data/media/0/Download/magisk_patched.img /data/media/0/Download/ksigam_dehctap.img; am force-stop com.epicgames.fortnite; sed -i -e 's/MobileFPSMode=Mode_20Fps/MobileFPSMode=Mode_60Fps/g' $GAMEUSERSETTINGS_FILE; sed -i -e 's/MobileFPSMode=Mode_30Fps/MobileFPSMode=Mode_60Fps/g'  $GAMEUSERSETTINGS_FILE; sed -i -e 's/MobileFPSMode=Mode_45Fps/MobileFPSMode=Mode_60Fps/g'  $GAMEUSERSETTINGS_FILE; sed -i -e 's/MobileFPSMode=Mode_60Fps/MobileFPSMode=Mode_60Fps/g'  $GAMEUSERSETTINGS_FILE; sed -i -e 's/MobileFPSMode=Mode_120Fps/MobileFPSMode=Mode_60Fps/g'  $GAMEUSERSETTINGS_FILE;;
8 ) TEXT3="✓PUBG : NEW STATE "; FCTEXT="PUBG: New State"; chmod 0777 /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; magiskhide enable; magiskhide add com.pubg.newstate; settings put global adb_enabled 0 settings put global development_settings_enabled 0; mv /data/media/0/TWRP /data/media/0/PRWT; mv /data/media/0/Download/magisk_patched.img /data/media/0/Download/ksigam_dehctap.img; am force-stop com.pubg.newstate; sed -i -e 's/FrameRateLimit=30.000000/FrameRateLimit=90.000000/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; sed -i -e 's/FrameRateLimit=30.000000/FrameRateLimit=90.000000/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; sed -i -e 's/FrameRateLimit=60.000000/FrameRateLimit=90.000000/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; sed -i -e 's/FrameRateLimit=60.000000/FrameRateLimit=90.000000/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; sed -i -e 's/AudioQualityLevel=2/AudioQualityLevel=0/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; sed -i -e 's/AudioQualityLevel=1/AudioQualityLevel=0/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; sed -i -e 's/LastConfirmedAudioQualityLevel=2/LastConfirmedAudioQualityLevel=0/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini; sed -i -e 's/LastConfirmedAudioQualityLevel=1/LastConfirmedAudioQualityLevel=0/g' /data/data/com.pubg.newstate/files/UE4Game/Extreme/Extreme/Saved/Config/Android/GameUserSettings.ini;;
9 ) TEXT3="✓RULES OF SURVIVORS "; FCTEXT=" RULES OF SURVIVORS "; sed -i '/ro.product.model/s/.*/ro.product.model=SM-G998B/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=SM-SM-G998B/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=SM-G998B/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=SM-G998B/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=SM-G998B/' $MODPATH/system.prop;;
10 ) TEXT3="✓PUBG MOBILE HDR EXTREME "; FCTEXT=" PUBG MOBILE HDR EXTREME "; sed -i '/ro.product.model/s/.*/ro.product.model=M2006J10C/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=M2006J10C/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=M2006J10C/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=M2006J10C/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=M2006J10C/' $MODPATH/system.prop;;
11 ) TEXT3="✓PUBG MOBILE & BGMI 90 FPS "; FCTEXT=" PUBG MOBILE & BGMI 90 FPS "; sed -i '/ro.product.model/s/.*/ro.product.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.odm.model/s/.*/ro.product.odm.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.system.model/s/.*/ro.product.system.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.vendor.model/s/.*/ro.product.vendor.model=GM1917/' $MODPATH/system.prop; sed -i '/ro.product.system_ext.model/s/.*/ro.product.system_ext.model=GM1917/' $MODPATH/system.prop;;
12 ) TEXT3="✓SKIP "; FCTEXT="Skip" ;;
esac
ui_print ""
ui_print " MODE : $FCTEXT "
ui_print "If You Like My Work "
ui_print " Buy Me A Coffee ☕ Plox"
am start -a android.intent.action.VIEW -d https://ko-fi.com/revWS/tiers >/dev/null 2>&1 & >/dev/null 2>&1 &
ui_print " join official tg channel @godTspeed & @godspeedmode "
am start -a android.intent.action.VIEW -d https://t.me/godTspeed >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
am start -a android.intent.action.VIEW -d https://t.me/godspeedmode >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
am start -a android.intent.action.VIEW -d https://t.me/premiumcookies4u >/dev/null 2>&1 & >/dev/null 2>&1 &
set_permissions() {
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
set_perm_recursive "$MODPATH/system/xbin" 0 0 0755 0755
}